#include "arquivo.h"


int learquivo(aluno **alunos, char *nome){
FILE *arquivo;
aluno a;
int i, j, t;
int NumAlunos;

arquivo=fopen(nome,"r");
if(arquivo==NULL){
  printf("Erro ao abrir o arquivo\n");
  return -1;
}
fscanf(arquivo,"%d",&NumAlunos);
*alunos = criaAluno(NumAlunos);
if(*alunos == NULL){
  printf("erro ao alocar alunos\n");
  return -1;
}
NumAlunos = NumAlunos * 8;
for (i = 0; i < NumAlunos; i++) {
    fscanf(arquivo,"%s",a.nome);
    fscanf(arquivo,"%f",&a.nota);
    salvarAluno(*alunos, a.nome, a.nota, i);
}

fclose(arquivo);
return NumAlunos;


}

int escreveArquivo(aluno *alunos, char *nome, int NumAlunos){
  FILE *arquivo;
  aluno a;
  int i = 0, Ap = 0, Rc = 0, Rp = 0;
  float Mediageral = 0;

  arquivo=fopen(nome,"w");
  if(arquivo==NULL){
      printf("Erro ao Salvar arquivo\n");
      return -1;
  }
  calcular(alunos, NumAlunos);
  mediaAluno(alunos, NumAlunos);
  NumAlunos = NumAlunos / 8;
  Mediageral=mediageral(alunos, NumAlunos);
  situacaoAluno(alunos, NumAlunos, &Ap, &Rc, &Rp);

  for (i = 0; i < NumAlunos; i++) {
      fprintf(arquivo, "%s %.2f %s \n", alunos[i].aux, alunos[i].media, alunos[i].situacao);
  }
      fprintf(arquivo, "Aprovados = %i \n", Ap);
      fprintf(arquivo, "Recuperacao = %i \n", Rc);
      fprintf(arquivo, "Reprovados = %i \n", Rp);
      fprintf(arquivo, "Media geral da turma= %.2f \n", Mediageral);
  fclose(arquivo);
  return 0;
}
