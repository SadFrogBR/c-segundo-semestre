#include "arquivo.h"

int main(int argc, char const *argv[]){
  aluno *alunos;
  int NumAlunos;
  int i;



  NumAlunos=learquivo(&alunos, (char *)argv[1]);
  escreveArquivo(alunos, (char *)argv[2], NumAlunos);

  free(alunos);
  return 0;
}
