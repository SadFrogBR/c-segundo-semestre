#include "aluno.h"

int learquivo(aluno **alunos, char *nome);
int escreveArquivo(aluno *alunos, char *nome, int NumAlunos);
