#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct x{
  char nome[50];
  char aux[50];
  char situacao[50];
  float nota;
  float media;
}aluno;

aluno * criaAluno(int n);
void salvarAluno(aluno *a, char *nome, float nota, int n);
void calcular(aluno *a, int n);
void mediaAluno(aluno *a, int n);
void situacaoAluno(aluno *a, int n, int *Ap, int *Rc, int *Rp);
float mediageral(aluno *a, int n);
