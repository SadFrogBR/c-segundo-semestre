#include "aluno.h"

aluno *criaAluno(int n){
  return malloc(sizeof(aluno)*n);
}

void salvarAluno(aluno *a, char *nome, float nota, int n){
  strcpy(a[n].nome,nome);
  a[n].nota=nota;
}


void calcular(aluno *a, int n) {
    int j = 0, k = 0, i = 0;

    for (i = 0; i < n; i++) {
        int dup = 0;

        for (k = 0; k < j; k++) {
            if (strcmp(a[i].nome, a[k].aux) == 0) {
                dup = 1;
                break;
            }
        }

        if (!dup) {
            strcpy(a[j].aux, a[i].nome);
            j++;
        }



    }

    printf("%s\n", a[i].aux);
}

void mediaAluno(aluno *a, int n) {
    int j = 0, q = 0, i = 0, div;
    div = n / 8;

    for(q = 0; q < div; q++){
      j = 0;
      for (i = 0; i <= n; i++) {
          if(j == 8){
            break;
          }
          else if (strcmp(a[i].nome, a[q].aux) == 0){
              a[q].media += a[i].nota;
              j++;
          }
      }
    }


}



void situacaoAluno(aluno *a, int n, int *Ap, int *Rc, int *Rp){
   int i = 0, app = 0, rec = 0, rpp = 0;
   for(i = 0; i < n; i++){

     if(a[i].media >= 6){
        strcat(a[i].situacao, "Aprovado");
        app++;
      }
      else if(a[i].media < 6 && a[i].media >= 4){
        strcat(a[i].situacao, "Recuperacao");
        rec++;
      }

      else if(a[i].media < 4){
        strcat(a[i].situacao, "Reprovado");
        rpp++;
      }
    }
    *Ap = app;
    *Rc = rec;
    *Rp = rpp;

    }

float mediageral(aluno *a, int n){
  int i = 0, j = 0;
  float mediageral;
  for(i = 0; i < n; i++){
   a[i].media = a[i].media / 8;
  }
  for(j = 0; j < n; j++){
    mediageral +=  a[j].media;
  }
    mediageral = mediageral / n;

  return mediageral;
}
