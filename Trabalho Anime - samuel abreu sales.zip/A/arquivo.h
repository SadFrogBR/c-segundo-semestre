#include "anime.h"


no* learquivo(no *anime, char *arg);
void menu();
int atualizaArquivo(no *animes, char *arg);
void escreve(no *animes, FILE *arquivo);
