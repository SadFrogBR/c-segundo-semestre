#include "anime.h"

no* salvarEp(no *aux, int ep, char *nome, char *resumo, int dia, int mes, int ano){
  no *auxep;
  auxep=malloc(sizeof(no));
  if(auxep==NULL){
    printf("Erro ao alocar\n");
    return aux;
  }
  auxep->ep=ep;

  strcpy(auxep->nome,nome);
  strcpy(auxep->resumo,resumo);
  auxep->dia=dia;
  auxep->mes=mes;
  auxep->ano=ano;
  auxep->prox=aux;
  return auxep;
}

no* inicializa(){
  return NULL;
}

void imprime(no *animes) {
  if(animes!=NULL){
    imprime(animes->prox);
    printf("------------------------------------\n");
    printf("Episodio numero: %d \n", animes->ep);
    printf("Nome: %s \n", animes->nome);
    printf("Resumo: %s \n", animes->resumo);
    printf("Dia: %d \n", animes->dia);
    printf("Mes: %d \n", animes->mes);
    printf("Ano: %d \n", animes->ano);
  }
}

no* adicionaep(no * animes){
  no *aux;
  aux=malloc(sizeof(no));
  if(aux==NULL){
    printf("Erro ao alocar\n");
    return animes;
  }
  printf("Digite o numero do episodio\n");
  scanf("%d", &aux->ep);
  printf("Digite o nome do episodio\n");
  scanf(" %[^\n]s", aux->nome);
  printf("Digite o resumo do episodio\n");
  scanf(" %[^\n]s", aux->resumo);
  printf("Digite o dia que assistiu o episodio\n");
  scanf("%d", &aux->dia);
  printf("Digite o mes que assistiu o episodio\n");
  scanf("%d", &aux->mes);
  printf("Digite o ano que assistiu o episodio\n");
  scanf("%d", &aux->ano);
  aux->prox=animes;
  return aux;

  }

  no* editaep(no *animes){
    no *aux;
    int ep;

    printf("Digite o numero do ep que deseja editar \n");
    scanf("%d", &ep);
    aux=buscar(animes,ep);
    if(aux!=NULL){
      printf("Digite o novo resumo do episodio \n");
      scanf(" %[^\n]", aux->resumo);
    }
    else{
      printf("ep não está na lista \n");
    }


    return animes;
  }

  no* removeep(no *animes){
    no *aux, *ant;
    int ep;
    aux=animes;

    printf("Digite o numero do ep que deseja remover \n");
    scanf("%d", &ep);

    if(animes->ep==ep){
      animes=animes->prox;
      aux->prox=NULL;
      free(aux);
      return animes;
    }

    while (aux->prox!=NULL) {
      ant=aux;
      aux=aux->prox;
     if(aux->ep==ep){
          ant->prox=aux->prox;
          aux->prox=NULL;
          free(aux);
          return animes;
      }

    }
    printf("Episodio não encontrado \n");
    return animes;
  }


  no * buscar(no *animes,int ep){
    no *aux;
    for (aux=animes;aux!=NULL;aux=aux->prox){
      if(aux->ep==ep){
        return aux;
      }
    }
    return NULL;
  }

int Vazia(no *animes){
  if(animes==NULL){
    return 1;
  }else{
    return 0;
  }
}

no * liberaLista(no *animes){
  no *ant,*aux;
  aux=animes;
  while (aux!=NULL) {
    ant=aux;
    aux=aux->prox;
    ant->prox=NULL;
    free(ant);
  }
  return NULL;
}
