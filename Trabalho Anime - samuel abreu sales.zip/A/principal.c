#include "arquivo.h"

int main(int argc, char const *argv[]) {
  no *animes=inicializa();
  int op, vazio;

  animes=learquivo(animes, (char *)argv[1]);
  do{
    menu();
    scanf("%d", &op);
    switch(op){
      case 1:
        vazio=Vazia(animes);
        if(vazio==0){
          imprime(animes);
        }else{
          printf("A lista está vazia\n");
        }
        break;
      case 2:
        animes=adicionaep(animes);
        break;
      case 3:
        vazio=Vazia(animes);
        if(vazio==0){
          animes=editaep(animes);
        }else{
          printf("A lista está vazia\n");
        }
        break;
      case 4:
        vazio=Vazia(animes);
        if(vazio==0){
          animes=removeep(animes);
        }else{
          printf("A lista está vazia\n");
        }
        break;
      case 5:
        atualizaArquivo(animes, (char *)argv[1]);
        break;
      case 0:
        printf("Programa fechado \n");
        break;
      default:
        printf("Opcao invalida, digite outra vez\n");
    }
  }while (op!=0);

  liberaLista(animes);
  return 0;
}
