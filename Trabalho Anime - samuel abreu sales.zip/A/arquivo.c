#include "arquivo.h"

no* learquivo(no *animes, char *arg){
  FILE *arquivo;
  no *aux;
  aux=animes;
  int ep, dia, mes, ano, i = 0;
  char nome[50];
  char resumo[300];

  arquivo=fopen(arg,"r");
  if(arquivo==NULL){
    printf("Erro ao abrir o arquivo\n");
    return animes;
  }


while(fscanf(arquivo, "%d", &ep) == 1){
  fscanf(arquivo," %[^\n]s", nome);
  fscanf(arquivo," %[^\n]s", resumo);
  fscanf(arquivo,"%d", &dia);
  fscanf(arquivo,"%d", &mes);
  fscanf(arquivo,"%d", &ano);
  aux=salvarEp(aux, ep, nome, resumo, dia, mes, ano);
}

  fclose(arquivo);
  return aux;
}

void menu(){
  printf("------------------------------ \n");
  printf("Digite a opcao desejada\n");
  printf("1)Listar episodios\n");
  printf("2)Adicionar episodio\n");
  printf("3)Editar resumo de um episodio\n");
  printf("4)Remover um episodio\n");
  printf("5)Atualizar os dados dos episodios\n");
  printf("0)Fecha o programa\n");
  printf("------------------------------ \n");
}

int atualizaArquivo(no *animes, char *arg){
  FILE *arquivo;
  no *aux;
  aux=animes;

  arquivo=fopen(arg,"w");
  if(arquivo==NULL){
    printf("Erro ao abrir o arquivo\n");
    return -1;
  }

    escreve(aux, arquivo);

    fclose(arquivo);
    return 0;

}

void escreve(no *animes, FILE *arquivo) {
  if(animes!=NULL){
    escreve(animes->prox, arquivo);
    fprintf(arquivo,"%d \n", animes->ep);
    fprintf(arquivo,"%s \n", animes->nome);
    fprintf(arquivo,"%s \n", animes->resumo);
    fprintf(arquivo,"%d \n", animes->dia);
    fprintf(arquivo,"%d \n", animes->mes);
    fprintf(arquivo,"%d \n", animes->ano);
  }
}
