#include <stdio.h>
#include <string.h>
#include <stdlib.h>

typedef struct anime{
  int ep;
  char nome[50];
  char resumo[300];
  int dia;
  int mes;
  int ano;
  struct anime * prox;
}no;

no* salvarEp(no *aux, int ep, char *nome, char *resumo, int dia, int mes, int ano);
no * inicializa();
void imprime(no *animes);
no * adicionaep(no * animes);
no* editaep(no *animes);
no* removeep(no *animes);
no * buscar(no *animes,int ep);
int Vazia(no *animes);
no * liberaLista(no *animes);
