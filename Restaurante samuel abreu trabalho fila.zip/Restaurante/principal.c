#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct n {
  char nome[50];
  long int telefone;
  long int cpf;
  struct n *prox;
} no;

typedef struct f {
  no *entrada;
  no *saida;
} fila;

typedef struct q {
  char nome[50];
  long int telefone;
  long int cpf;
  struct q *prox;
} re;

typedef struct w {
  re *entrada;
  re *saida;
} fila2;

int learquivo(fila *F);
int inserir(fila *F, long int telefone, char *nome, long int cpf);
int inserirSemReserva(fila2 *F2);
int proxCliente(fila *F, fila2 *F2);
int removeReserva(fila *F);
int removeSemReserva(fila2 *F2);
void inicializa(fila *F);
void inicializa2(fila2 *F2);
void menu();

int main(int argc, char const *argv[]) {
  fila F;
  fila2 F2;
  int op;
  inicializa(&F);
  inicializa2(&F2);
  learquivo(&F);
  do {
    menu();
    scanf(" %d", &op);
    switch (op) {
      case 1:
        inserirSemReserva(&F2);
        break;
      case 2:
        proxCliente(&F, &F2);
        break;
      case 0:
        printf("Programa sendo fechado\n");
        break;
      default:
      printf("Não existe essa opcao \n");
      break;
    }
  } while (op != 0);

  return 0;
}

int learquivo(fila *F) {
  FILE *arquivo;
  char nome[50];
  long int telefone;
  long int cpf;
  arquivo = fopen("reserva.txt", "r");
  if (arquivo == NULL) {
    printf("Erro ao abrir o arquivo\n");
    return 1;
  }

  while (fscanf(arquivo, "%ld", &telefone) == 1) {
    fscanf(arquivo, "%s", nome);
    fscanf(arquivo, "%ld", &cpf);
    inserir(F, telefone, nome, cpf);
  }

  fclose(arquivo);
  return -1;
}

int inserir(fila *F, long int telefone, char *nome, long int cpf) {
  no *aux;
  aux = malloc(sizeof(no));
  if (aux == NULL) {
    printf("Erro ao alocar no\n");
    return 1;
  }
  aux->telefone = telefone;
  aux->cpf = cpf;
  strcpy(aux->nome, nome);
  if (F->saida == NULL) {
    F->saida = aux;
  }
  aux->prox = F->entrada;
  F->entrada = aux;
  return 0;
}

int inserirSemReserva(fila2 *F2) {
  re *aux;
  aux = malloc(sizeof(re));
  if (aux == NULL) {
    printf("Erro ao alocar no\n");
    return 1;
  }
  printf("Digite o nome do cliente\n");
  scanf(" %[^\n]s", aux->nome);
  printf("Digite o numero de telefone dele\n");
  scanf("%ld", &aux->telefone);
  printf("Digite o CPF dele\n");
  scanf("%ld", &aux->cpf);
  if (F2->saida == NULL) {
    F2->saida = aux;
  }
  aux->prox = F2->entrada;
  F2->entrada = aux;
  return 0;
}

int proxCliente(fila *F, fila2 *F2) {
  if (F->entrada != NULL) {
    removeReserva(F);
    return 0;
  }
  if (F2->entrada != NULL) {
    removeSemReserva(F2);
    return 0;
  } else {
    printf("Não tem mais clientes\n");
    return 0;
  }
}

int removeReserva(fila *F) {
  no *aux, *ant;
  aux = F->saida;
  ant = F->entrada;
  if (F->saida == NULL) {
    printf("fila vazia\n");
    return 1;
  }
  printf("-------------Mesa disponivel-------------\n");
  printf("-------------Proximo cliente-------------\n");
  printf("Nome do cliente: %s\n", aux->nome);
  printf("Telefone do cliente: %ld\n", aux->telefone);
  printf("CPF do cliente: %011ld\n", aux->cpf);
  printf("Fez reserva: Sim\n");
  printf("---------------------------------------\n");
  if (ant == aux) {
    free(aux);
    inicializa(F);
    return 0;
  }
  while (ant->prox != aux) {
    ant = ant->prox;
  }
  F->saida = ant;
  ant->prox = NULL;
  free(aux);
  return 0;
}

int removeSemReserva(fila2 *F2) {
  re *aux, *ant;
  aux = F2->saida;
  ant = F2->entrada;
  if (F2->saida == NULL) {
    printf("fila vazia\n");
    return 1;
  }
  printf("-------------Mesa disponivel-------------\n");
  printf("-------------Proximo cliente-------------\n");
  printf("Nome do cliente: %s\n", aux->nome);
  printf("Telefone do cliente: %ld\n", aux->telefone);
  printf("CPF do cliente: %011ld\n", aux->cpf);
  printf("Fez reserva: Não\n");
  printf("---------------------------------------\n");
  if (ant == aux) {
    free(aux);
    inicializa2(F2);
    return 0;
  }
  while (ant->prox != aux) {
    ant = ant->prox;
  }
  F2->saida = ant;
  ant->prox = NULL;
  free(aux);
  return 0;
}

void inicializa(fila *F) {
  F->entrada = NULL;
  F->saida = NULL;
}

void inicializa2(fila2 *F2) {
  F2->entrada = NULL;
  F2->saida = NULL;
}

void menu() {
  printf("--------Menu---------\n");
  printf("1) Cadastrar cliente sem reserva\n");
  printf("2) Mesa disponivel, proximo cliente\n");
  printf("0) Sair\n");
}
