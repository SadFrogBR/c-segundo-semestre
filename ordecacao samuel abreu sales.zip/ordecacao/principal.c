#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {
    int id;
    char nome[50];
    int dia, mes, ano;
    int Hinicio, Minicio, Hfinal, Mfinal;
} Corredor;

Corredor* lerResultados(const char* nomeArquivo, int* numCorredores) {
    FILE* arquivo = fopen(nomeArquivo, "r");
    if (arquivo == NULL) {
        printf("Erro ao abrir o arquivo.\n");
        exit(1);
    }

    Corredor* corredores = NULL;
    int id;
    *numCorredores = 0;

    while (fscanf(arquivo, "%d", &id) == 1) {
        Corredor* novoCorredor = (Corredor*)malloc(sizeof(Corredor));
        novoCorredor->id = id;
        fscanf(arquivo, " %[^\n]s", novoCorredor->nome);
        fscanf(arquivo, "%d", &(novoCorredor->dia));
        fscanf(arquivo, "%d", &(novoCorredor->mes));
        fscanf(arquivo, "%d", &(novoCorredor->ano));
        fscanf(arquivo, "%d", &(novoCorredor->Hinicio));
        fscanf(arquivo, "%d", &(novoCorredor->Minicio));
        fscanf(arquivo, "%d", &(novoCorredor->Hfinal));
        fscanf(arquivo, "%d", &(novoCorredor->Mfinal));

        (*numCorredores)++;
        corredores = (Corredor*)realloc(corredores, (*numCorredores) * sizeof(Corredor));
        corredores[(*numCorredores) - 1] = *novoCorredor;
        free(novoCorredor);
    }

    fclose(arquivo);
    return corredores;
}

void trocarCorredores(Corredor* corredores, int i, int j) {
    Corredor temp = corredores[i];
    corredores[i] = corredores[j];
    corredores[j] = temp;
}

void selectSort(Corredor* corredores, int numCorredores) {
    for (int i = 0; i < numCorredores - 1; i++) {
        int indiceMenor = i;
        for (int j = i + 1; j < numCorredores; j++) {
            if (corredores[j].Hfinal < corredores[indiceMenor].Hfinal ||
                (corredores[j].Hfinal == corredores[indiceMenor].Hfinal &&
                 corredores[j].Mfinal < corredores[indiceMenor].Mfinal)) {
                indiceMenor = j;
            }
        }
        trocarCorredores(corredores, i, indiceMenor);
    }
}

void insertionSort(Corredor* corredores, int numCorredores) {
    for (int i = 1; i < numCorredores; i++) {
        int j = i;
        while (j > 0 &&
               (corredores[j].Hfinal < corredores[j - 1].Hfinal ||
                (corredores[j].Hfinal == corredores[j - 1].Hfinal &&
                 corredores[j].Mfinal < corredores[j - 1].Mfinal))) {
            trocarCorredores(corredores, j, j - 1);
            j--;
        }
    }
}

void imprimirRanking(Corredor* corredores, int numCorredores) {
    for (int i = 0; i < numCorredores; i++) {
        printf("--------------%d Lugar--------------------------\n", i+1);
        printf("id = %d \n%s\n", corredores[i].id, corredores[i].nome);
         printf("Data de nascimento: %02d/%02d/%d\n", corredores[i].dia, corredores[i].mes, corredores[i].ano);
        printf("Tempo: %02d:%02d\n", corredores[i].Hfinal - corredores[i].Hinicio, corredores[i].Mfinal - corredores[i].Minicio);
    }
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Uso: ./programa <nome_arquivo> <metodo_ordenacao>\n");
        printf("Ex: ./programa entrada.txt insert\n");
        return 1;
    }

    const char* nomeArquivo = argv[1];
    const char* metodoOrdenacao = argv[2];

    int numCorredores;
    Corredor* corredores = lerResultados(nomeArquivo, &numCorredores);

    if (strcmp(metodoOrdenacao, "select") == 0) {
        selectSort(corredores, numCorredores);
    } else if (strcmp(metodoOrdenacao, "insert") == 0) {
        insertionSort(corredores, numCorredores);
    } else {
        printf("Método de ordenação inválido. Use 'select' ou 'insert'.\n");
        return 1;
    }

    imprimirRanking(corredores, numCorredores);

    free(corredores);

    return 0;
}
